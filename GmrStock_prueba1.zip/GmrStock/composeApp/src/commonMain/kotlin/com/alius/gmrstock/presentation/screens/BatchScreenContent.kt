package com.alius.gmrstock.presentation.screens

import androidx.compose.runtime.Composable
import com.alius.gmrstock.domain.model.User

@Composable
fun BatchScreenContent(user: User) {
    // usa user aquí dentro
}
