package com.alius.gmrstock.domain.model

data class User(
    val id: String,
    val email: String
)
