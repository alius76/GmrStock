package com.alius.gmrstock.presentation.screens

import androidx.compose.runtime.Composable
import com.alius.gmrstock.domain.model.User

@Composable
fun MaterialScreenContent(user: User) {
    // usa user aquí dentro
}
