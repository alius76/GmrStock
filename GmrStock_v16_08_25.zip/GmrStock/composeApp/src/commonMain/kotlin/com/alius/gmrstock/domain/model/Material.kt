package com.alius.gmrstock.domain.model

data class Material(
    val id : String ="",
    val materialNombre: String = "",
)