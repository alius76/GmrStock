package com.alius.gmrstock.data

object FirestoreUrls {
    const val DB1_URL = "https://firestore.googleapis.com/v1/projects/gmrstock/databases/(default)/documents:runQuery"
    const val DB2_URL = "https://firestore.googleapis.com/v1/projects/prueba-af1e8/databases/(default)/documents:runQuery"
}
