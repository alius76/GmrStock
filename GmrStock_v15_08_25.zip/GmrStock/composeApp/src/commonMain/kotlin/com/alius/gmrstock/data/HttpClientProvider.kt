package com.alius.gmrstock.data

import io.ktor.client.*

expect fun createHttpClient(): HttpClient