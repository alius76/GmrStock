package com.alius.gmrstock.data

expect fun getDatabaseLogoPath(fileName: String): String